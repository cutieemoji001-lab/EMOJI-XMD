
<p align="center">
  <a href="https://github.com/novaxmd/BMB-XMD-DATA/raw/refs/heads/main/bmb.jpg">
    <img src="https://i.postimg.cc/bwRBhLp3/5042f575-5d62-426c-821e-273d383cef49.jpg" width="100%" height="auto">
  </a>
</p>

CLICK HERE TO DEPLOY YOUR OWN WHATSAPP BOT 


<a href="https://deployment-gk6k.vercel.app/">
  <img 
    title="DEPLOY-NOW" 
    src="https://img.shields.io/badge/DEPLOY--NOW-Click%20to%20deploy-brightgreen?style=for-the-badge&logo=vercel&logoColor=black"
    width="300" 
    height="40.45"
    alt="Deploy with Vercel"
  />
</a>
